#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "decode.h"
#include "types.h"
#include "common.h"

/* Open stego and output files */
Status open_decode_files(DecodeInfo *decInfo)
{
    decInfo->fptr_stego_image = fopen(decInfo->stego_image_fname, "r");  //open stego image in read mode
    if (decInfo->fptr_stego_image == NULL)  //check if it is null or not
    {
        perror("fopen");
        fprintf(stderr, "ERROR: Unable to open file %s\n", decInfo->stego_image_fname); //if null print error message
        return e_failure;
    }

    decInfo->fptr_secret1 = fopen(decInfo->secret_f1name, "w"); //open optional file in write mode
    if (decInfo->fptr_secret1 == NULL)
    {
        perror("fopen");
        fprintf(stderr, "ERROR: Unable to open file %s\n", decInfo->secret_f1name);
        fclose(decInfo->fptr_stego_image); //close optional file
        return e_failure;
    }

    return e_success;
}

/* Validate decode arguments */
Status read_and_validate_decode_args(char *argv[], DecodeInfo *decInfo)
{
    if ((strstr(argv[2], ".bmp")) != NULL) //check if .bmp is present or not
        strcpy(decInfo->stego_image_fname, argv[2]);
    else
    {
        printf("Error: .bmp file is not present or invalid\n");
        return e_failure;
    }

    if (argv[3] != NULL) //check if it is not equal to null
        strcpy(decInfo->secret_f1name, argv[3]);
    else
    {
        printf("Output file not provided.\n");
        strcpy(decInfo->secret_f1name, "decoded"); //copy default file name as decoded
    }
    return e_success;
}

/* Decode a byte from 8 LSBs */
char decode_byte_from_lsb(FILE *fptr_stego)
{
    unsigned char buffer[8];
    char ch = 0;

    if (fread(buffer, 1, 8, fptr_stego) != 8) //read 8 bytes of data
    {
        printf("Failed to read 8 bytes from stego image\n");
        return 0;
    }

    for (int i = 0; i < 8; i++) //run a loop
    {
        ch = (ch << 1) | (buffer[i] & 1); //getting a bit
    }
    return ch; //return each character
}

/* Decode magic string */
Status decode_magic_string(const char *magic_string, DecodeInfo *decInfo)
{
    fseek(decInfo->fptr_stego_image, 54, SEEK_SET);  // BMP data offset
    char magic[3];
    magic[0] = decode_byte_from_lsb(decInfo->fptr_stego_image); // storing first character
    magic[1] = decode_byte_from_lsb(decInfo->fptr_stego_image); //storing second character
    magic[2] = '\0'; //null

    if (strcmp(magic, magic_string) == 0) //comparing both encoded and decoded strings 
        return e_success;
    else
    {
        printf("Magic string mismatch\n");  //if string is mismatched
        return e_failure;
    }
}

/* Decode extension size */
Status decode_extension_file_size(DecodeInfo *decInfo)
{
    unsigned char buffer[32];
    int extn_size = 0;

    if (fread(buffer, 1, 32, decInfo->fptr_stego_image) != 32) //read 32 bytes of data
    {
        printf("Failed to read extension size bits\n");
        return e_failure;
    }

    for (int i = 0; i < 32; i++)
    {
        extn_size = (extn_size << 1) | (buffer[i] & 1); //storing each byte
    }
    decInfo->extn_size = extn_size; //copying it to extension size
    return e_success;
}

/* Decode extension */
Status decode_secret_file_extn(DecodeInfo *decInfo)
{
    
    for (int i = 0; i < decInfo->extn_size; i++)
    {
        char ch = decode_byte_from_lsb(decInfo->fptr_stego_image);
        decInfo->extn_secret_file[i] = ch;
    }
    decInfo->extn_secret_file[decInfo->extn_size] = '\0'; //adding null to last byte

    
    if (decInfo->secret_f1name[0] == '\0')
    {
        sprintf(decInfo->secret_f1name, "decoded%s", decInfo->extn_secret_file); //if it is equal to null print error message
    }
    else if (strchr(decInfo->secret_f1name, '.') == NULL)
    {
        strcat(decInfo->secret_f1name, decInfo->extn_secret_file); //concatenating with .txt
    }

    printf("Output file name: %s\n", decInfo->secret_f1name); //printf optional file name
    return e_success;
}


/* Decode secret file size */
Status decode_secret_file_size(DecodeInfo *decInfo)
{
    unsigned char buffer[32];
    int file_size = 0;

    if (fread(buffer, 1, 32, decInfo->fptr_stego_image) != 32) //read 32 bytes of data
    {
        fprintf(stderr, "Failed to read secret file size bits\n"); //prints error message
        return e_failure;
    }

    for (int i = 0; i < 32; i++)
    {
        file_size = (file_size << 1) | (buffer[i] & 1); 
    }
    decInfo->size_secret_file = file_size; //storing file size 
    return e_success;
}

/* Decode secret file data */
Status decode_secret_file_data(DecodeInfo *decInfo)
{
    char ch;
    for (int i = 0; i < decInfo->size_secret_file; i++)
    {
        ch = decode_byte_from_lsb(decInfo->fptr_stego_image); //function return each character
        fputc(ch, decInfo->fptr_secret1); //prints each character
    }
    return e_success;
}

/* Main decoding routine */
Status do_decoding(DecodeInfo *decInfo)
{
    if (open_decode_files(decInfo) == e_failure)
    {
        return e_failure;
    }
    else
    printf("All the files opened sucessfully\n");

    if (decode_magic_string(MAGIC_STRING, decInfo) == e_failure)
    {
        return e_failure;
    }
    else
    printf("Decoded magic string successfully\n");

    if (decode_extension_file_size(decInfo) == e_failure)
    {
        return e_failure;
    }
    else
    printf("Decoded extension file size successfully\n");

    if (decode_secret_file_extn(decInfo) == e_failure)
    {
        return e_failure;
    }
    else
    printf("Decoded secret file extension successfully\n");

    if (decode_secret_file_size(decInfo) == e_failure)
    {
        return e_failure;
    }
    else
    printf("Decoded secret file size successfully\n"); 

    if (decode_secret_file_data(decInfo) == e_failure)
    {
        return e_failure;
    }
    else
    printf("Decoded secret file data successfully\n");
    
    fclose(decInfo->fptr_stego_image);
    fclose(decInfo->fptr_secret1);

    return e_success;
}
