#ifndef DECODE_H
#define DECODE_H

#include "types.h" // Contains user defined types

/* 
 * Structure to store information required for
 * encoding secret file to source Image
 * Info about output and intermediate data is
 * also stored
 */

#define MAX_SECRET_BUF_SIZE 1
#define MAX_IMAGE_BUF_SIZE (MAX_SECRET_BUF_SIZE * 8)
#define MAX_FILE_SUFFIX 4

typedef struct DecodeInfo
{
    /* Source Image info */
    char stego_image_fname[100]; //STORE ADDRESS OF SOURCE FILE NAME
    FILE *fptr_stego_image;  //STORE ADDRESS OF THIS FILE
    

    /* Secret File Info */
    char secret_f1name[100]; //STORE FILE NAME OF SECRET FILE
    FILE *fptr_secret1; //ADDRESS OF SECRET FILE
    char extn_secret_file[MAX_FILE_SUFFIX]; //EXTENSION OF SECRET FILE i.e .txt
    long size_secret_file;

    int extn_size;

}DecodeInfo;


/* Encoding function prototype */

/* Check operation type (-e or -d) */
OperationType check_operation_type(char *argv[]);

/* Read and validate decoding arguments from command line */
Status read_and_validate_decode_args(char *argv[], DecodeInfo *decInfo);

/* Main function that performs the decoding process */
Status do_decoding(DecodeInfo *decInfo);

/* Open stego image file and output secret file */
Status open_decode_files(DecodeInfo *decInfo);

/* Decode and validate the magic string embedded in the image */
Status decode_magic_string(const char *magic_string, DecodeInfo *decInfo);

/* Decode the file extension of the hidden secret file */
Status decode_secret_file_extn(DecodeInfo *decInfo);

/* Decode the size of the hidden secret file */
Status decode_secret_file_size(DecodeInfo *decInfo);

/* Decode the actual hidden secret file data */
Status decode_secret_file_data(DecodeInfo *decInfo);

/* (Unused in decoding) - Encodes data to image - belongs to encoding */
Status decode_data_to_image(char *data, int size, FILE *fptr_src_image, FILE *fptr_stego_image);

/* (Misnamed) - Used in encoding: Embed one byte into 8 LSBs of image buffer */
Status decode_byte_to_lsb(char data, char *image_buffer);

/* (Misnamed) - Used in encoding: Embed a 4-byte int into 32 LSBs */
Status decode_size_to_lsb(int data, char *image_buffer);

/* Decode the size of the file extension */
Status decode_extension_file_size(DecodeInfo *decInfo);

#endif