#include <stdio.h>
#include<string.h>
#include<stdlib.h>
#include "encode.h"
#include "types.h"
#include "common.h"

/* Function Definitions */

/* Get image size
 * Input: Image file ptr
 * Output: width * height * bytes per pixel (3 in our case)
 * Description: In BMP Image, width is stored in offset 18,
 * and height after that. size is 4 bytes
 */
uint get_image_size_for_bmp(FILE *fptr_image)
{
    uint width, height;
    // Seek to 18th byte
    fseek(fptr_image, 18, SEEK_SET);

    // Read the width (an int)
    fread(&width, sizeof(int), 1, fptr_image); //18 TO 22
    printf("width = %u\n", width);

    // Read the height (an int)
    fread(&height, sizeof(int), 1, fptr_image); //23 TO 27
    printf("height = %u\n", height);

    // Return image capacity
    return width * height * 3;
}

/* 
 * Get File pointers for i/p and o/p files
 * Inputs: Src Image file, Secret file and
 * Stego Image file
 * Output: FILE pointer for above files
 * Return Value: e_success or e_failure, on file errors
 */
Status open_files(EncodeInfo *encInfo)  //src image is opened
{
    // Src Image file
    encInfo->fptr_src_image = fopen(encInfo->src_image_fname, "r");
    // Do Error handling
    if (encInfo->fptr_src_image == NULL)
    {
    	perror("fopen"); //perror shows the reason why it is not opening
    	fprintf(stderr, "ERROR: Unable to open file %s\n", encInfo->src_image_fname);

    	return e_failure;
    }

    // Secret file
    encInfo->fptr_secret = fopen(encInfo->secret_fname, "r");
    // Do Error handling
    if (encInfo->fptr_secret == NULL)
    {
    	perror("fopen");
    	fprintf(stderr, "ERROR: Unable to open file %s\n", encInfo->secret_fname);

    	return e_failure;
    }

    // Stego Image file
    encInfo->fptr_stego_image = fopen(encInfo->stego_image_fname, "w");
    // Do Error handling
    if (encInfo->fptr_stego_image == NULL)
    {
    	perror("fopen");
    	fprintf(stderr, "ERROR: Unable to open file %s\n", encInfo->stego_image_fname);

    	return e_failure;
    }

    // No failure return e_success
    return e_success;
}
Status read_and_validate_encode_args(char *argv[], EncodeInfo *encInfo)
{
     // -> .bmp file

    if ((strstr(argv[2], ".bmp")) != NULL)  //check if argv[2] is .bmp file 
    {
        strcpy(encInfo->src_image_fname, argv[2]); //store the src_image in encinfo-> src_image_fname
    }
    else
    {
        printf(".bmp file is not present\n");  //print the error msg and return e_failure
        return e_failure;
    }
    if ((strstr(argv[3], ".txt")) != NULL)   //check if argv[3] is .txt file or not,
    { 
        strcpy(encInfo->secret_fname, argv[3]);     //store the secret_file name in secret_fname 
        strcpy(encInfo->extn_secret_file, ".txt");  //store the extn in extn_sec_file
    }
    else
    {
        printf(".txt file is not present\n");  //printf the error message and return e_failure
        return e_failure;
    }
    if (argv[4] && strstr(argv[4], ".bmp") != NULL)  //check if argv[4] is passed or not
    {
        strcpy(encInfo->stego_image_fname, argv[4]);   //store the file name in stego_image_fname
    }
    else if (argv[4] == NULL)
    {
        strcpy(encInfo->stego_image_fname, "stego.bmp"); // print the msg and store the default file name[stego.bmp] in stego_image_fname
    }
    else
    {
        printf(".bmp file is not present\n");
        return e_failure;
    }

    return e_success;
    

}
Status encode_byte_to_lsb(char data, char *image_buffer)
{
    for(int i=0;i<8;i++)
    {
    image_buffer[i]=((data>>(7-i))&1)|(image_buffer[i]&~1); //get the msb bit in data and clear the lsb bit in image buffer
    }
    return e_success;
}
uint get_file_size(FILE *fptr)
{
     fseek(fptr, 0, SEEK_END);  //move the pos to the end of file[fseek]

    long size = ftell(fptr);    //return the pos[ftell]

    return (uint)size;
}
Status check_capacity(EncodeInfo *encInfo)
{

    uint image_capacity = get_image_size_for_bmp(encInfo->fptr_src_image);
    encInfo->size_secret_file = get_file_size(encInfo->fptr_secret);


    if(image_capacity > 54+(strlen(MAGIC_STRING) * 8 + 32+ strlen(encInfo->extn_secret_file) * 8 + 32  + encInfo->size_secret_file * 8))
    {
        return e_success;
    }
    else
    {
        return e_failure;
    }
}
Status copy_bmp_header(FILE *fptr_src_image,FILE *fptr_stego_image)
{
    rewind(fptr_src_image);

    char buffer[54];

    if(fread(buffer,1,54,fptr_src_image)!=54)   //read 54 bytes from src and store into buffer
    {
        printf("failed to read bmp header\n");
        return e_failure;
    }
    if(fwrite(buffer,1,54,fptr_stego_image)!=54) //write 54 bytes into dest 
    {
        printf("failed to write bmp header\n");
        return e_failure;
    }
    return e_success;
}
Status encode_magic_string(const char *magic_string,EncodeInfo *encInfo)
{
    return encode_data_to_image((char*)magic_string,strlen(magic_string),encInfo->fptr_src_image, encInfo->fptr_stego_image);
    
}
Status encode_data_to_image(char *data, int size, FILE *fptr_src_image, FILE *fptr_stego_image)

{
    char image_buffer[8];
    for(int i=0;i<size;i++)  //run the loops of size times
    {
       fread(image_buffer,1,8,fptr_src_image);    //read the 8 bytes from the src_image
       encode_byte_to_lsb(data[i],image_buffer);  //call the encode_byte_to_lsb(data[i],image_buffer)
       fwrite(image_buffer,1,8,fptr_stego_image); //write the 8 bytes to the stego_image
    }
    printf("magic string encoded succesfully\n"); //return e_sucess and print magic string successfully
    return e_success;
}
Status encode_size_to_lsb(int data, char *image_buffer)
{
    for(int i=0;i<32;i++)  //iterating till 32
    {
    image_buffer[i]=((data>>(31-i))&1)|(image_buffer[i]&~1); //get the msb bit in data and clear the lsb bit in image buffer
    }
    return e_success;
}
Status encode_extension_file_size(long extn_size, EncodeInfo *encInfo)
{
    char image_buffer[32];
    fread(image_buffer,1,32,encInfo->fptr_src_image);   //read 32 bytes from the src
    encode_size_to_lsb(extn_size,image_buffer);         //call the size_to_lsb()
    fwrite(image_buffer,1,32,encInfo->fptr_stego_image); ////write 32 bytes to the dest

    return e_success;
}
Status encode_secret_file_extn(const char *file_extn, EncodeInfo *encInfo)
{
   return encode_data_to_image((char *)file_extn, strlen(file_extn),encInfo->fptr_src_image, encInfo->fptr_stego_image);
}



Status encode_secret_file_size(long file_size, EncodeInfo *encInfo)
{
    char image_buffer[32];
    fread(image_buffer,1,32,encInfo->fptr_src_image);    //read 32 bytes from the src
    encode_size_to_lsb(file_size, image_buffer);         //call the size_to_lsb()
    fwrite(image_buffer,1,32,encInfo->fptr_stego_image); //write 32 bytes to the dest
    return e_success;

}
Status encode_secret_file_data(EncodeInfo *encInfo)
{
    int file_size = get_file_size(encInfo->fptr_secret); // or use encInfo->size_secret_file
    char *data = malloc(file_size);
    rewind(encInfo->fptr_secret);
    fread(data, sizeof(char), file_size, encInfo->fptr_secret); //read secret file data into data

if (encode_data_to_image(data, file_size, encInfo->fptr_src_image, encInfo->fptr_stego_image) == e_failure)
{
    printf("Error encoding secret file data\n");
    return e_failure;
}
    return e_success;
}
Status copy_remaining_img_data(FILE *fptr_src, FILE *fptr_stego)
{
    char ch;

    while(fread(&ch,1,1,fptr_src)>0) //reading 1 byte by byte till it becomes negative
    {
        fwrite(&ch,1,1,fptr_stego); //writing into the destination file
    }
    return e_success;
}
Status do_encoding(EncodeInfo *encInfo)
{   
    //only function calls inside it
    if(open_files(encInfo)==e_failure)
    {
        printf("error\n");
        return e_failure;
    }
    else
    {
        printf("opened the files successfully\n");
    }

    if(check_capacity(encInfo)==e_failure)
    {
        printf("error\n");
        return e_failure;

    }
    else
    {
        printf("Image capacity is checked\n");
    }
    if(copy_bmp_header(encInfo->fptr_src_image, encInfo->fptr_stego_image) == e_failure)
    {
        return e_failure;
    }
    else
    printf("Copied the headers successfully\n");

    if(encode_magic_string(MAGIC_STRING,encInfo)==e_failure)
    {
        printf("error\n");
        return e_failure;
    }
    else{
        printf("Magic string encoded successfully");
    }
    if(encode_extension_file_size(strlen(encInfo->extn_secret_file),encInfo)==e_failure)
    {
       printf("error\n");
       return e_failure;
    }
    else
    {
     printf("Encoded the extension file size successfully\n");
    }
    if(encode_secret_file_extn(encInfo->extn_secret_file,encInfo)==e_failure)
    {
        return e_failure;
    }
    else
    printf("Encoded the secret file extension successfully\n");
    if(encode_secret_file_size(encInfo->size_secret_file, encInfo) == e_failure)
    {
        printf("error\n");
        return e_failure;
    }
    else
    printf("Encoded the secret file size Successfully\n");
    if(encode_secret_file_data(encInfo)==e_failure)
    {
        printf("error\n");
        return e_failure;
    }
    else
    printf("Encoded the secret file data successfully\n");

    if(copy_remaining_img_data(encInfo->fptr_src_image,encInfo->fptr_stego_image)==e_failure)
    {
        printf("error\n");
        return e_failure;
    }
    else
    {
        printf("All the remaining data is copied\n");
        return e_success;
    }
}