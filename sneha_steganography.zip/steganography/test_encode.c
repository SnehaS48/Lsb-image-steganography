#include <stdio.h>
#include<string.h>
#include "encode.h"
#include "types.h"
#include "decode.h"
OperationType check_operation_type(char *argv[])
{
    if(strcmp(argv[1],"-e")==0)
    {
        return e_encode;
    }
    else if(strcmp(argv[1],"-d")==0)
    {
        return e_decode;
    }
    else
    {
        printf("unsupported format\n");
        return e_unsupported;
    }
}
int main(int argc, char *argv[])
{
    printf("Argc: %d\n", argc);
    for (int i = 0; i < argc; i++)
    printf("argv[%d] = %s\n", i, argv[i]);
    int ret= check_operation_type(argv); //function call to check encode or decode
    if(ret==e_encode)
    {
        printf("perform encoding\n");
        EncodeInfo encInfo;
        if(read_and_validate_encode_args(argv,&encInfo)==e_success)  //read and validate
        {
            printf("read and validation executed succesfully\n");
            if(do_encoding(&encInfo)==e_success)
            {
                printf("Encode is performed succesfully\n"); //after checking all functions
            }
            else
            {
                printf("error\n");
            }

        }
        else
        {
            printf("error\n");
        }
    }
    else if(ret==e_decode)
    { 
        printf("perform decoding\n");
        DecodeInfo decInfo;
        if(read_and_validate_decode_args(argv,&decInfo)==e_success)  //read and validate all the files
        {
            printf("read and validation executed succesfully\n");
            if(do_decoding(&decInfo)==e_success)
            {
                printf("Decode is performed succesfully\n"); //after checking all the decoding process
            }
            else
            {
                printf("error\n");
            }

        }
        else
        {
            printf("error\n");
        }
    }
    else
    {
        printf("error:unsupported format\n");
    }

    return 0;
}
